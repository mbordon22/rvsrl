<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" x="0"
 y="0" viewBox="0 0 {{ $originalImageWidth }} {{ $originalImageHeight }}">
	<image width="{{ $originalImageWidth }}" height="{{ $originalImageHeight }}" xlink:href="{{ $tinyImageBase64 }}">
	</image>
</svg>