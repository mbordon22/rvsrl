<?php

return [
 /*
  |--------------------------------------------------------------------------
  | Database settings
  |--------------------------------------------------------------------------
  |
  | The name of the table to create in the database
  |
  */
  'table_name' => 'countries',
];
