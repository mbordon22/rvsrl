# Laravel DataTables Buttons Plugin CHANGELOG.

## v11.2.2 - 2025-01-18

- Fix: Avoid redundant call to buildExcelFile in csv method #191
- Fixes #192

## v11.2.1 - 2024-09-14

- fix: fast-excel exporting of related models #189

## v11.2.0 - 2024-09-03

- feat: fast-excel export via Column's exportRender() #187

## v11.1.0 - 2024-09-02

- feat: fast-excel export cell styling via exportFormat #186

## v11.0.0 - 2024-03-14

- Laravel 11.x support
