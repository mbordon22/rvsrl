# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.x     | :white_check_mark: |
| 11.x    | :white_check_mark: |

## Reporting a Vulnerability

If you discover any security related issues, please email aqangeles@gmail.com instead of using the issue tracker.
