Attached you will find requested report.
