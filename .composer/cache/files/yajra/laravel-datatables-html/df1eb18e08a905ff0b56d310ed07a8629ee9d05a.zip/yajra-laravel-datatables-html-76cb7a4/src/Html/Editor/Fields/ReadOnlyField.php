<?php

namespace Yajra\DataTables\Html\Editor\Fields;

class ReadOnlyField extends Field
{
    protected string $type = 'readonly';
}
